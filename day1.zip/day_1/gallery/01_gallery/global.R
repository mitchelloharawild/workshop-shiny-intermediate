paintings <- read.csv("data/gallery.csv", stringsAsFactors = FALSE)
